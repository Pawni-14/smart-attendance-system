# Smart Proxy Attendance System

A secure web-based attendance system built using Flask and SQLite.

## Features

- Face recognition verification (simulated logic)
- Campus network restriction
- Duplicate attendance prevention
- Attractive UI with animations
- College branding

## Technologies Used

- Python
- Flask
- SQLite
- HTML, CSS
- JavaScript

## How to Run

1. Install requirements
2. Run: python app.py
3. Open: http://127.0.0.1:5000/

## Author
Pawni Khurana