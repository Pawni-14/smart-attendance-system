from flask import request
from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)

# Initialize database
def init_db():
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reg_no TEXT NOT NULL,
            lecture_id TEXT NOT NULL,
            date TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()

init_db()

@app.route("/")
def home():
    return render_template("index.html")

# API to mark attendance
@app.route("/mark_attendance", methods=["POST"])
def mark_attendance():
    user_ip = request.remote_addr

    if user_ip != "127.0.0.1":
        return jsonify({"message": "Attendance allowed only on college network"}), 403

    reg_no = request.form.get("reg_no")
    lecture_id = request.form.get("lecture_id")
    from datetime import datetime
    date = request.form.get("date")
    date = datetime.strptime(date, "%Y-%m-%d").strftime("%Y-%m-%d")

    if not reg_no or not lecture_id or not date:
        return render_template("index.html", message="Missing data")

    # Fake face verification: only allow reg numbers starting with 1
    if not reg_no.startswith("1"):
        return render_template("index.html", message="Face verification failed")

    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM attendance WHERE reg_no=? AND lecture_id=? AND date=?",
        (reg_no, lecture_id, date)
    )
    existing = cursor.fetchone()

    if existing:
        conn.close()
        return render_template("index.html", message="Attendance already marked for this lecture")

    try:
        cursor.execute(
        "INSERT INTO attendance (reg_no, lecture_id, date) VALUES (?, ?, ?)",
        (reg_no, lecture_id, date)
        )
        conn.commit()
        message = "Attendance marked successfully!"
    except Exception as e:
     conn.close()
     return render_template("index.html", message="Error: " + str(e))

    conn.close()
    return render_template("index.html", message=message)
# API to get all students
@app.route("/students", methods=["GET"])
def get_students():
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM attendance")
    students = cursor.fetchall()

    conn.close()

    return jsonify(students)
@app.route("/quick_mark")
def quick_mark():
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO attendance (reg_no, lecture_id, date) VALUES (?, ?, ?)",
        ("12345", "L1", "2026-02-15")
    )

    conn.commit()
    conn.close()

    return "Attendance Added!"
@app.route("/")
def index():
    return render_template("index.html")
if __name__ == "__main__":
    app.run(debug=True) 